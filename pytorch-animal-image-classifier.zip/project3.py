import os
import random
from typing import Dict, List
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Subset
from PIL import Image
from sklearn.metrics import classification_report, confusion_matrix


RANDOM_SEED = 42


def set_reproducible_seed(seed=RANDOM_SEED):
    """Seed Python and PyTorch and request deterministic operations when available."""
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ----------------------------
# Species Knowledge Base
# ----------------------------
ANIMAL_INFO: Dict[str, str] = {
    "cat": "Small carnivorous mammal with soft fur and retractable claws.",
    "dog": "Domesticated carnivorous mammal known for loyalty.",
    "horse": "Large herbivorous mammal used for riding and racing.",
    "bird": "Small animal with wings."
}

# CIFAR-10 class indices
TARGET_CLASSES = {
    2: 0,
    3: 1,
    5: 2,  
    7: 3   
}

IDX_TO_CLASS = {
    0: "bird",
    1: "cat",
    2: "dog",
    3: "horse"
}


# ----------------------------
# CNN Architecture
# ----------------------------
class AnimalCNN(nn.Module):
    def __init__(self):
        super(AnimalCNN, self).__init__()

        self.features = nn.Sequential(
            # Block 1
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),  

            # Block 2
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),  

            # Block 3
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2),  

            # Extra block for stronger features
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),

            nn.AdaptiveAvgPool2d((1, 1))
        )

        self.classifier = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(128, 4)
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


# ----------------------------
# Dataset Acquisition and Filtering 
# ----------------------------
class FilteredCIFAR10(torch.utils.data.Dataset):
    def __init__(self, base_dataset, target_map):
        self.base_dataset = base_dataset
        self.target_map = target_map

        self.indices: List[int] = [
            i for i, label in enumerate(base_dataset.targets)
            if label in target_map
        ]

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        image, original_label = self.base_dataset[self.indices[idx]]
        remapped_label = self.target_map[original_label]
        return image, remapped_label


# ----------------------------
# Data Loaders
# ----------------------------
def get_dataloaders(batch_size=64):
    train_transform = transforms.Compose([
        transforms.Resize((64, 64)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(
            (0.485, 0.456, 0.406),
            (0.229, 0.224, 0.225)
        )
    ])

    test_transform = transforms.Compose([
        transforms.Resize((64, 64)),
        transforms.ToTensor(),
        transforms.Normalize(
            (0.485, 0.456, 0.406),
            (0.229, 0.224, 0.225)
        )
    ])

    train_dataset = torchvision.datasets.CIFAR10(
        root="./data",
        train=True,
        download=True,
        transform=train_transform
    )

    test_dataset = torchvision.datasets.CIFAR10(
        root="./data",
        train=False,
        download=True,
        transform=test_transform
    )

    filtered_train = FilteredCIFAR10(train_dataset, TARGET_CLASSES)
    filtered_test = FilteredCIFAR10(test_dataset, TARGET_CLASSES)

    train_loader = DataLoader(filtered_train, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(filtered_test, batch_size=batch_size, shuffle=False)

    return train_loader, test_loader


# ----------------------------
# Training / Evaluation
# ----------------------------
def train_model(model, train_loader, test_loader, device, epochs=8, lr=0.001):
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        train_acc = 100.0 * correct / total
        test_acc = evaluate_model(model, test_loader, device)

        print(
            f"Epoch [{epoch + 1}/{epochs}] | "
            f"Loss: {running_loss / len(train_loader):.4f} | "
            f"Train Acc: {train_acc:.2f}% | "
            f"Test Acc: {test_acc:.2f}%"
        )


def evaluate_model(model, data_loader, device):
    model.eval()
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in data_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs, 1)

            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    return 100.0 * correct / total if total > 0 else 0.0


def print_detailed_evaluation(model, data_loader, device):
    """Print per-class precision, recall, F1, and a confusion matrix."""
    model.eval()
    actual = []
    predicted = []

    with torch.no_grad():
        for images, labels in data_loader:
            images = images.to(device)
            outputs = model(images)
            batch_predictions = torch.argmax(outputs, dim=1).cpu()
            actual.extend(labels.tolist())
            predicted.extend(batch_predictions.tolist())

    class_names = [IDX_TO_CLASS[index] for index in range(len(IDX_TO_CLASS))]
    print("\nDetailed test-set evaluation")
    print(classification_report(
        actual,
        predicted,
        labels=list(range(len(class_names))),
        target_names=class_names,
        digits=4,
        zero_division=0,
    ))
    print("Confusion matrix (rows=actual, columns=predicted):")
    print(confusion_matrix(actual, predicted, labels=list(range(len(class_names)))))


# ----------------------------
# Inference Function
# ----------------------------
def predict_image(model, image_path, device):
    inference_transform = transforms.Compose([
        transforms.Resize((64, 64)),
        transforms.ToTensor(),
        transforms.Normalize(
            (0.485, 0.456, 0.406),
            (0.229, 0.224, 0.225)
        )
    ])

    image = Image.open(image_path).convert("RGB")
    image_tensor = inference_transform(image).unsqueeze(0).to(device)

    model.eval()
    with torch.no_grad():
        outputs = model(image_tensor)
        probabilities = torch.softmax(outputs, dim=1)
        confidence, predicted_idx = torch.max(probabilities, 1)

    predicted_idx = predicted_idx.item()
    confidence = confidence.item() * 100
    predicted_class = IDX_TO_CLASS[predicted_idx]
    description = ANIMAL_INFO[predicted_class]

    print(f"\nTARGET FILE: {os.path.basename(image_path)}")
    print(f"PREDICTION:  {predicted_class.upper()}")
    print(f"CONFIDENCE:  {confidence:.2f}%")
    print(f"DESCRIPTION: {description}")


# ----------------------------
# Main
# ----------------------------
def main():
    set_reproducible_seed()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    model = AnimalCNN().to(device)
    model_path = "animal_cnn.pth"

    train_loader, test_loader = get_dataloaders(batch_size=64)

    # Train model if no saved model exists
    if not os.path.exists(model_path):
        print("No saved model found. Training a new model...")
        train_model(model, train_loader, test_loader, device, epochs=8, lr=0.001)
        torch.save(model.state_dict(), model_path)
        print(f"Model saved to {model_path}")
    else:
        print(f"Loading saved model from {model_path}...")
        model.load_state_dict(torch.load(model_path, map_location=device, weights_only=True))

    print_detailed_evaluation(model, test_loader, device)

    # CWD Inference
    target_file = "test_animal_image.jpg"

    if not os.path.exists(target_file):
        print(f"\nFile not found in current working directory: {target_file}")
        print(f"Current working directory: {os.getcwd()}")
        return

    predict_image(model, target_file, device)


if __name__ == "__main__":
    main()
